<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title> Bus Pass Management System | contact-us </title>
    <link rel="stylesheet" href="css/stylecontact.css">
    <!-- Fontawesome CDN Link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>

<div class="container">
    <div class="content">
      <div class="left-side">
        <div class="address details">
          <i class="fas fa-map-marker-alt"></i>
          <div class="topic">Address</div>
          <div class="text-one">Pune,Shivaji-nagar</div>
          <div class="text-two">behind Sancheti-hospital-411003</div>
        </div>
        <div class="phone details">
          <i class="fas fa-phone-alt"></i>
          <div class="topic">Phone</div>
          <div class="text-one">+91 7385463212</div>
          <div class="text-two">+91 9734345678</div>
        </div>
        <div class="email details">
          <i class="fas fa-envelope"></i>
          <div class="topic">Email</div>
          <div class="text-one">buspassms@gmail.com</div>
          <div class="text-two">businessbuspass@gmail.com</div>
        </div>
      </div>
      <div class="right-side">
        <div class="topic-text">Send us a message</div>
        <p>If you have any  types of quries related to bus-pass you can send me message from here. </p>
      <form action="#" method="POST">
        <div class="input-box">
          <input type="text" placeholder="Enter your name" name="namee" required>
        </div>
        <div class="input-box">
          <input type="text" placeholder="Enter your email" name="email" required>
        </div>
        <div class="input-box message-box">
          <textarea placeholder="Enter your message" name="messagee" required></textarea>
        </div>
        <div class="button">
          <input type="submit" value="Send Now" name="sent">
        </div>
      </form>
    </div>
    </div>
  </div>

</body>
</html>

<?php
 function function_alert($message)
 {
   echo"<script> alert('$message');document.location ='homepage.php';</script>";
 }
?>
<?php
 function function_else($message)
 {
   echo"<script> alert('$message');document.location ='contactus.php';</script>";
 }
?>

<?php
include("connection.php");
if (isset ($_POST['sent']))
   {
       $name=$_POST['namee'];
       $email=$_POST['email'];
       $message=$_POST['messagee'];
       

       $query="INSERT INTO contactform (name1,email1,message1) VALUES ('$name','$email','$message')";
       
       $query_run=mysqli_query($conn,$query);

       if($query_run)
       {
           function_alert("Your Message sent !!! you will get Reply As soon As possible on your GMAIL");
           
       }
       else{
           function_else("Message not sent please Try Again . Thank You ");
       }


   }

   ?>