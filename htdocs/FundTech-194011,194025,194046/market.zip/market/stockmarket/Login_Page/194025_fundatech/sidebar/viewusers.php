<!DOCTYPE html>
<html>

<head>
   
    <title> Funda_Tech | Users-Profiles </title>   
    <link href="assets/plugins/bootstrap/bootstrap.css" rel="stylesheet" />
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
   <link href="assets/css/style.css" rel="stylesheet" />
   <link href="assets/css/main-style.css" rel="stylesheet" />
   <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />

</head>

<body>
    
    <div id="wrapper">
       <?php include_once('includes/header.php');?>
        <?php include_once('includes/sidebar.php');?>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">All-Users-Profiles</h1>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                      
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>  
                                            <th class="text-center">User-ID</th>                                       
                                            <th class="text-center">Username</th>
                                            <th class="text-center">Password</th>
                                            <th class="text-center">Gender-ID</th>
                                            <th class="text-center">Email</th>
                                            <th class="text-center">Phone-Code</th>
                                            <th class="text-center">Phone</th>
                                            <th class="text-center">Premium</th>
                                            <th class="text-center">Operation</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
$sql="SELECT * from signup";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);

$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $row)
{               ?>
                <tr>   
                  <td class="text-center"><?php  echo htmlentities($row->id);?></td>              
                  <td class="text-center"><?php  echo htmlentities($row->username);?></td>
                  <td class="text-center"><?php  echo htmlentities($row->password);?></td>
                  <td class="text-center"><?php  echo htmlentities($row->gender);?></td>
                  <td class="text-center"><?php  echo htmlentities($row->email);?></td>
                  <td class="text-center"><?php  echo htmlentities($row->phonecode);?></td>
                  <td class="text-center"><?php  echo htmlentities($row->phonecode);?></td>
                  <td class="text-center"><?php  echo htmlentities($row->premium);?></td>
                  <td class="text-center"><a href="deleteuser.php?viewid=<?php echo htmlentities ($row->id);?>"><i class="fa fa-trash"></i></a> </td>
                </tr>
               <?php $cnt=$cnt+1;}} ?>  
                                       
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
          </div> 
        </div>
    </div>
    

   
    <script src="assets/plugins/jquery-1.10.2.js"></script>
    <script src="assets/plugins/bootstrap/bootstrap.min.js"></script>
    <script src="assets/plugins/metisMenu/jquery.metisMenu.js"></script>
    
    <script src="assets/scripts/siminta.js"></script>
    <script src="assets/plugins/dataTables/jquery.dataTables.js"></script>
    
    <script>
        $(document).ready(function () {
            $('#dataTables-example').dataTable();
        });
    </script>

</body>

</html>
