<?php
$servername = "localhost";
$usrename   = "root";
$password   = "";
$dbname     = "phpproject"; 

$conn = mysqli_connect("localhost","root","","phpproject");

if($conn)
{
    echo"";
}else
{
    echo"SQL database Connection Failed";
}

?>