<!DOCTYPE html>
<html>

<head>
   
    <title>Add Company Data | Funda_Tech </title>   
    <link href="assets/plugins/bootstrap/bootstrap.css" rel="stylesheet" />
    <link href="assets/plugins/bootstrap/myset.css" rel="stylesheet" />
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
   <link href="assets/css/style.css" rel="stylesheet" />
   <link href="assets/css/main-style.css" rel="stylesheet" />
   <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />

</head>

<body>

<form action="" method="POST">
    
    <div id="wrapper">
       <?php include_once('includes/header.php');?>
        <?php include_once('includes/sidebar.php');?>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Enter Company Data</h1>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel ">
                      
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover " id="dataTables-">
                                    <thead >
                                        
                                        <tr>                                         
                                            <th><input type="text" placeholder="Enter Company Name" name="sname"></th>
                                            <th class="text-center">2017 - 03</th>
                                            <th class="text-center">2018 - 03</th>
                                            <th class="text-center">2019 - 03</th>
                                            <th class="text-center">2020 - 03</th>
                                            <th class="text-center">2021 - 03</th>
                                            
                                        </tr>
                                       
                                    </thead>
                                    <tbody>

                <tr>                 
                  <th>Revenue</th>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s1" ></td>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s2" ></td>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s3" ></td>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s4" ></td>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s5" ></td>
                </tr>
                <tr>                 
                  <th>Operating Income</th>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s6" ></td>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s7" ></td>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s8" ></td>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s9" ></td>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s10" ></td>
                </tr>
                <tr>                 
                  <th>Net Income</th>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s11" ></td>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s12" ></td>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s13" ></td>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s14" ></td>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s15" ></td>
                </tr>
                <th>Eps</th>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s16" ></td>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s17" ></td>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s18" ></td>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s19" ></td>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s20" ></td>
                </tr>
                <th>ReDividends</th>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s21" ></td>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s22" ></td>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s23" ></td>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s24" ></td>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s25" ></td>
                </tr>
                <th>Operating Cash Flow Per Share </th>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s26" ></td>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s27" ></td>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s28" ></td>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s29" ></td>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s30" ></td>
                </tr>
                <th>Free Cash Flow</th>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s31" ></td>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s32" ></td>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s33" ></td>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s34" ></td>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s35" ></td>
                </tr>
                <th>Free Cash Flow Per Share</th>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s36" ></td>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s37" ></td>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s38" ></td>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s39" ></td>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s40" ></td>
                </tr>
                <th>Working Capital</th>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s41" ></td>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s42" ></td>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s43" ></td>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s44" ></td>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s45" ></td>
                </tr>
                <th>Return on Assests</th>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s46" ></td>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s47" ></td>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s48" ></td>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s49" ></td>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s50" ></td>
                </tr>
                <th>Return On Equity</th>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s51" ></td>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s52" ></td>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s53" ></td>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s54" ></td>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s55" ></td>
                </tr>
                <th>Return On Invested Capital</th>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s56" ></td>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s57" ></td>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s58" ></td>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s59" ></td>
                  <td><input type="text" class="col-xs-7 " placeholder="1" name="s60" ></td>
                </tr>
                    
                                       
                                        
               </tbody>
                                </table>
                                <div class="text-center">
                                <button type="submit" class="btn btn-primary btn-lg" name="submit" id="submit" >Insert The Data</button></div>
                            </div>
                        </div>
                    </div>
                </div>
          </div> 
        </div>
    </div>

    

   
    <script src="assets/plugins/jquery-1.10.2.js"></script>
    <script src="assets/plugins/bootstrap/bootstrap.min.js"></script>
    <script src="assets/plugins/metisMenu/jquery.metisMenu.js"></script>
    
    <script src="assets/scripts/siminta.js"></script>
    <script src="assets/plugins/dataTables/jquery.dataTables.js"></script>
    
    <script>
        $(document).ready(function () {
            $('#dataTables-example').dataTable();
        });
    </script>

</form>
</body>

</html>
<?php



function function_alert($message)
{
  echo"<script> alert('$message');document.location ='addcdata.php';</script>";
}


function function_else($message)
{
  echo"<script> alert('$message');document.location ='addcdata.php';</script>";
}

 
 if(isset($_POST['submit']))
 {
     $stockname = $_POST['sname'];
     $stname = $_POST['s1'];
     $cmweb = $_POST['s2'];
     $bse = $_POST['s3'];
     $nse = $_POST['s4'];
     $cp = $_POST['s5'];
     $pp = $_POST['s6'];
     $pa = $_POST['s7'];
     $pb = $_POST['s8'];
     $pc = $_POST['s9'];
     $pd = $_POST['s10'];
     $pe = $_POST['s11'];
     $pf = $_POST['s12'];
     $pg = $_POST['s13'];
     $ph = $_POST['s14'];
     $pi = $_POST['s15'];
     $pj = $_POST['s16'];
     $pk = $_POST['s17'];
     $pl = $_POST['s18'];
     $pm = $_POST['s19'];
     $pn = $_POST['s20'];
     $po = $_POST['s21'];
     $pq = $_POST['s22'];
     $pr = $_POST['s23'];
     $ps = $_POST['s24'];
     $pt = $_POST['s25'];
     $pu = $_POST['s26'];
     $pv = $_POST['s27'];
     $pw = $_POST['s28'];
     $px = $_POST['s29'];
     $py = $_POST['s30'];
     $pz = $_POST['s31'];
     $sa = $_POST['s32'];
     $sb = $_POST['s33'];
     $sc = $_POST['s34'];
     $sd = $_POST['s35'];
     $se = $_POST['s36'];
     $sf = $_POST['s37'];
     $sg = $_POST['s38'];
     $sh = $_POST['s39'];
     $si = $_POST['s40'];
     $sj = $_POST['s41'];
     $sk = $_POST['s42'];
     $sl = $_POST['s43'];
     $sm = $_POST['s44'];
     $sn = $_POST['s45'];
     $so = $_POST['s46'];
     $sp = $_POST['s47'];
     $sq = $_POST['s48'];
     $sr = $_POST['s49'];
     $ss = $_POST['s50'];
     $st = $_POST['s51'];
     $su = $_POST['s52'];
     $sv = $_POST['s53'];
     $sw = $_POST['s54'];
     $sx = $_POST['s55'];
     $sy = $_POST['s56'];
     $sz = $_POST['s57'];
     $za = $_POST['s58'];
     $zb = $_POST['s59'];
     $zc = $_POST['s60'];
     




     $host = "localhost";
     $dbUsername = "root";
     $dbPassword = "";
     $dbName = "phpproject";

     $conn = new mysqli($host, $dbUsername, $dbPassword, $dbName);


     $enter = "INSERT INTO addfunda(sname,s1,s2,s3,s4,s5,s6,s7,s8,s9,s10,s11,s12,s13,s14,s15,s16,s17,s18,s19,s20,s21,s22,s23,s24,s25,s26,s27,s28,s29,s30,s31,s32,s33,s34,s35,s36,s37,s38,s39,s40,s41,s42,s43,s44,s45,s46,s47,s48,s49,s50,s51,s52,s53,s54,s55,s56,s57,s58,s59,s60)values('$stockname','$stname','$cmweb','$bse','$nse','$cp','$pp','$pa','$pb','$pc','$pd','$pe','$pf','$pg','$ph','$pi','$pj','$pk','$pl','$pm','$pn','$po','$pq','$pr','$ps','$pt','$pu','$pv','$pw','$px','$py','$pz','$sa','$sb','$sc','$sd','$se','$sf','$sg','$sh','$si','$sj','$sk','$sl','$sm','$sn','$so','$sp','$sq','$sr','$ss','$st','$su','$sv','$sw','$sx','$sy','$sz','$za','$zb','$zc')";
   
   $data = mysqli_query($conn,$enter);
  
   if($data)
   {
    function_alert("Company Data Has Been inserted");
   }
   else
   {
    function_else("Somethin Went Wrong please Try Again");
   }
}
?>