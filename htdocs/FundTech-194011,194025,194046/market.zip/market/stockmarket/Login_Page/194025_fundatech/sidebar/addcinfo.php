<!DOCTYPE html>
<html>

<head>
   
    <title>Funda_Tech | ADD Company Info</title>   
    <link href="assets/plugins/bootstrap/bootstrap.css" rel="stylesheet" />
    <link href="assets/plugins/bootstrap/myset.css" rel="stylesheet" />
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
   <link href="assets/css/style.css" rel="stylesheet" />
   <link href="assets/css/main-style.css" rel="stylesheet" />
   <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />

</head>

<body>
<form action="" method="POST" enctype='multipart/form-data'>
    
    <div id="wrapper">
       <?php include_once('includes/header.php');?>
        <?php include_once('includes/sidebar.php');?>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-5">
                    <h1 class="page-header">ADD Company Info</h1>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-10">
                    <div class="panel panel-default">
                      
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>                                         
                                            <th><input type="text" name="stname" class="col-xs-7" placeholder="Enter Company Name" class="col-xs-8"> </th>
                                            <th  class="text-center">Company Details</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        
                <tr>                 
                  <th class="text-center">Company Website</th>
                  <td><textarea class="form-control z-depth-1" name="cmweb" id="exampleFormControlTextarea6" rows="3" placeholder="Write something here..."></textarea></td>
                  </tr>
                  <tr>                 
                  <th class="text-center">BSE Website</th>
                  <td><textarea class="form-control z-depth-1" name="bse" id="exampleFormControlTextarea6" rows="3" placeholder="Write something here..."></textarea></td>
                  </tr>
                  <tr>                 
                  <th class="text-center">NSE Website</th>
                  <td><textarea class="form-control z-depth-1" name="nse" id="exampleFormControlTextarea6" rows="3" placeholder="Write something here..."></textarea></td>
                  </tr>
                  <tr>                 
                  <tr>                 
                  <th class="text-center">About Company/Company Basic Information</th>
                  <td><textarea class="form-control z-depth-1" name="abt" id="exampleFormControlTextarea6" rows="3" placeholder="Write something here..."></textarea></td>
                  </tr>
                 
                                       
                                        
                                    </tbody>
                                </table>
                                <div class="text-center">
                                <button type="submit" class="btn btn-primary btn-lg" name="submit" id="submit" >Insert The Info</button></div>
                            </div>
                        </div>
                    </div>
                </div>
          </div> 
        </div>
    </div>
    

   
    <script src="assets/plugins/jquery-1.10.2.js"></script>
    <script src="assets/plugins/bootstrap/bootstrap.min.js"></script>
    <script src="assets/plugins/metisMenu/jquery.metisMenu.js"></script>
    
    <script src="assets/scripts/siminta.js"></script>
    <script src="assets/plugins/dataTables/jquery.dataTables.js"></script>
    
    <script>
        $(document).ready(function () {
            $('#dataTables-example').dataTable();
        });
    </script>
</form>
</body>

</html>

<?php
 function function_alert($message)
 {
   echo"<script> alert('$message');document.location ='addcinfo.php';</script>";
 }
 
 
 function function_else($message)
 {
   echo"<script> alert('$message');document.location ='addcinfo.php';</script>";
 }   
    
    

    
    if(isset($_POST['submit']))
    {
        $stname = $_POST['stname'];
        $cmweb = $_POST['cmweb'];
        $bse = $_POST['bse'];
        $nse = $_POST['nse'];
        $cp = $_POST['cp'];
        $mp = $_POST['mp'];
        $fv = $_POST['fv'];
        $hl= $_POST['hl'];
        $pe = $_POST['pe'];
        $abt = $_POST['abt'];
        $host = "localhost";
        $dbUsername = "root";
        $dbPassword = "";
        $dbName = "phpproject";
        $conn = new mysqli($host, $dbUsername, $dbPassword, $dbName);
        
        $imgContent = addslashes(file_get_contents($image)); 
        function_alert($filename); 
        $enter = "INSERT INTO info(stname,cmweb,bse,nse,cp,mp,fv,hl,pe,abt)values('$stname','$cmweb','$bse','$nse','$cp','$mp','$fv','$hl','$pe','$abt')";
      
      $data = mysqli_query($conn,$enter);
     
      if($data)
      {
        function_alert("information has been inserted successfully !! "); 
      }
      else
      {
        function_else("Somethin Went Wrong please Try Again");
      }
  }
 ?>