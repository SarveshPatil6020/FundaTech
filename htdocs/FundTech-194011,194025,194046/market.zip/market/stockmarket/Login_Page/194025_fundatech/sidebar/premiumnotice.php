<!DOCTYPE html>
<html>

<head>
    
    <title> Funda_Tech| Add Admin</title>
    <link href="assets/plugins/bootstrap/bootstrap.css" rel="stylesheet" />
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/css/style.css" rel="stylesheet" />
      <link href="assets/css/main-style.css" rel="stylesheet" />



</head>

<body>
    
    <div id="wrapper">
      <?php include_once('includes/header.php');?>
        <?php include_once('includes/sidebar.php');?>
          <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Add Notice</h1>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                       
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-12">
                                    <form method="post" action="notice.php"> 
                                    
    <div class="form-group"> <label for="exampleInputEmail1">Company Name</label> <input type="text" name="company"  class="form-control" required='true'> </div>
    <div class="form-group"> <label for="exampleInputEmail1">Add Notice</label> <input type="text" name="notice"  class="form-control" required='true'> </div>
     <p style="padding-left: 450px"><button type="submit" class="btn btn-primary" name="submit" id="submit">Add</button></p> 
    
      </form>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                     
                </div>
            </div>
        </div>
        
    </div>
    
    <script src="assets/plugins/jquery-1.10.2.js"></script>
    <script src="assets/plugins/bootstrap/bootstrap.min.js"></script>
    <script src="assets/plugins/metisMenu/jquery.metisMenu.js"></script>
   
    <script src="assets/scripts/siminta.js"></script>

</body>

</html>

<?php
    if(isset($_POST['submit']))
  {


 $user=$_POST['usernamee'];
 $pass=$_POST['passwordd'];


$sql="insert into adminform(username,password)values(:usernamee,:passwordd)";
$query=$dbh->prepare($sql);
$query->bindParam(':usernamee',$user,PDO::PARAM_STR);
$query->bindParam(':passwordd',$pass,PDO::PARAM_STR);

$query->execute();

   $LastInsertId=$dbh->lastInsertId();
   if ($LastInsertId>0) {
    echo '<script>alert("New Admin has been added.")</script>';
echo "<script>window.location.href ='viewadmins.php'</script>";
  }
  else
    {
         echo '<script>alert("Something Went Wrong. Please try again")</script>';
    }

  

}

?>