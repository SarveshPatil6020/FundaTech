<?php
include("connection.php");

 function function_alert($message)
 {
   echo"<script> alert('$message');document.location ='viewusers.php';</script>";
 }


 function function_else($message)
 {
   echo"<script> alert('$message');document.location ='viewusers.php';</script>";
 }
 $eid=$_GET['viewid'];
$del ="DELETE FROM signup WHERE id=$eid";
    
$dataa = mysqli_query($conn,$del);
       
       if($dataa)
       {
           function_alert("User Removed !!!!!");
       }
       else
       {
           function_else("Unable to remove !!!!");
       }

?>