<?php

error_reporting(0);
include('includes/dbconnection.php');
?>
        <nav class="navbar-default navbar-static-side" role="navigation">
            
            <div class="sidebar-collapse">
                <ul class="nav" id="side-menu">
                    <li>
                        
                            <div class="user-info">                        
                    </li>
                    <li class="selected">
                        <a href="homepage.php"><i class="fa fa-home"></i>  Logout</a>
                    </li>
                    <li class="selected">
                        <a href="dashboard.php"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                    </li>
                    <li>
                        
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-building"></i> Add_Company <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            
                            <li>
                                <a href="addcdata.php">Add_Company_Stats</a>
                                <a href="addcinfo.php">Add_Company_Info</a>
                                <a href="addchart.php">Add_Company_chart</a>
                                <a href="addchart1.php">Add_Company_2nd chart</a>
                            </li>
                        </ul>
                    </li>
                   
                    <li>
                        <a href="#"><i class="fa fa-envelope"></i> Enquiry<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                            <a href="unreadenq.php">Enquiry Section</a>
                            </li>
                        </ul>
                    </li>
                    
                    <li>
                        <a href="#"><i class="fa fa-user"></i> User-Settings<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                            <a href="viewusers.php">All-Users-Profiles</a>
                            </li>
                        </ul>
                    </li>
                    
                    <li>
                        <a href="#"><i class="fa fa-lock"></i> Premium User-Settings<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="premiumnotice.php">Add Notice</a>
                            </li>
                            
                            </ul>
                    </li>
                     
                    
                    <li>
                        <a href="#"><i class="fa fa-lock"></i> Admin-Settings<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="viewadmins.php">All-Admin-Profiles</a>
                            </li>
                            <li>
                                <a href="addadmin.php">Add-Admin-Profile</a>
                            </li>
                            </ul>
                        </ul>
                     </li>
                     
                     
                
            </div>
        </nav>