<?php
include("connection.php");

 function function_alert($message)
 {
   echo"<script> alert('$message');document.location ='viewadmins.php';</script>";
 }


 function function_else($message)
 {
   echo"<script> alert('$message');document.location ='viewadmins.php';</script>";
 }
 $eid=$_GET['viewid'];

$del ="DELETE FROM adminform WHERE id=$eid";
    
$dataa = mysqli_query($conn,$del);
       
       if($dataa)
       {
           function_alert("Admin Has been Deleted !!!!");
       }
       else
       {
           function_else("Unable to Delete Admin ");
       }

?>