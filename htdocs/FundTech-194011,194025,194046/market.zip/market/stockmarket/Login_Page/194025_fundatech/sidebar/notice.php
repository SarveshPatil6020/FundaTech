<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "phpproject";
// Create connection
$conn = new mysqli($servername, $username, $password,$dbname);

$sql = "INSERT INTO `noticeboard` (`company`,`notice`)
VALUES ('".$_POST['company']."','".$_POST['notice']."')";
if ($conn->query($sql) === TRUE) {
    echo "successfully added";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}


$conn->close();
?>