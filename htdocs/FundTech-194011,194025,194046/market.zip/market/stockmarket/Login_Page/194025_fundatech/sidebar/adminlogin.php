<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="includes/loginstyle.css">
    <title>Admin Login page </title>
</head>
<body>
    <div class="center">
        <h1>Admin-Login</h1>
        <form action= "#" method="post">
          <div class="txt_field">
            <input type="text" required name="user">
            <span></span>
            <label>Username</label>
          </div>
          <div class="txt_field">
            <input type="password" required name="pass">
            <span></span>
            <label>Password</label>
          </div>
          
          <input type="submit" value="Login" name="enter" onclick="myFunction()">
          
        </div>
        </form>
      </div>

    
</body>
</html>

<?php
 function function_alert($message)
 {
   echo"<script> alert('$message');document.location ='dashboard.php';</script>";
 }
?>
<?php
 function function_else($message)
 {
   echo"<script> alert('$message');document.location ='adminlogin.php';</script>";
 }
?>

<?php
include("connection.php");
if(isset($_POST['enter']))
{
  $uname=$_POST['user'];
  $password=$_POST['pass'];



  $stmt = $conn->prepare("select * from adminform where password = ?");
  $stmt->bind_param("s",$password);
  $stmt->execute();
  $stmt_result = $stmt->get_result();
  if($stmt_result->num_rows > 0)
  {
     $data = $stmt_result->fetch_assoc();
     if($data['password'] == $password)
     {
      function_alert("Admin-Login Successfull");
        
     }else{
      function_else("Username or Password invalid");
     }
  }
  else{
    function_else("Username or Password invalid");
  }
}
 

   ?>