<!DOCTYPE html>
<html lang="en">
<head>
      
  <title> stock </title>
  <style> table, th, td {border : 2px solid rgba(17, 2, 2, 0.904);}</style>
</head>
<body bgcolor=yellow > 
    <h3 align="center">
        <font face="Arial black" size="25" color="blue">FundaTech</font>
        <table id="header" border="1" width="100%" cellpadding="0" >
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      
        
        <font face="Arial black" size="4" color="blue"> 
        &nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <a href="#"><font color="blue">News</font></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <a href="login.html"><font color="blue">login</font></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <a href="#"><font color="blue">Subscription</font></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <a href="contact.php"><font color="blue">Contact us</font></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        </font>
        </h3> 
    </table><table id="header" border="1" width="100%" cellpadding="0" ></table><table id="header" border="1" width="100%" 
    cellpadding="0" ></table><table id="header" border="1" width="100%" cellpadding="0" ></table>
    
    
  <h1>

     
    </br></br></br>
    <font face="Arial black" size="10" color="black">Vdafone Idea ltd :-</font>
    </br><a href="https://www.myvi.in/"><font size="5"color="red">Website</font></a>&nbsp;&nbsp;&nbsp;&nbsp;
    <a href="https://www.bseindia.com/stock-share-price/vodafone-idea-ltd/IDEA/532822/"><font size="5" color="red">BSE</font></a>&nbsp;&nbsp;&nbsp;&nbsp;
    <a href="https://www.nseindia.com/get-quotes/equity?symbol=IDEA"><font size="5" color="red">NSE</font></a>
    </br>
    <font face="Arial black" size="5" color="black">Current price = 13.8 &nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  Market Cap = 39.48Tcr&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Face Value = 10</br>
    High/Low= ₹16.8 / 4.55&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
    PE Ratio=_ _&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </font>
    </table><table id="header" border="1" width="100%" cellpadding="0" ></table>
    </br></br></br></br>
    <font face="Arial black" size="7" color="green">About Vodafone Idea :-</font>
    </br></br>
    <font face="Arial black" size="5" color="black">Vodafone Idea is one of the leading telecom service providers in India. The Company is engaged in the 
        business of Mobility and Long Distance services, trading of handsets and data cards.Presently, the company has a subscriber base of ~272 million 
        subscribers across India. The company's subscribers has declined from 311 million in 2019 to 272 million in 2020.The company merged both brands
        of Vodafone and Idea into a new single entity i.e. 'VI' in September 2020, two years after the merger of two companies.</font>
         </br>
        <table id="header" border="1" width="100%" cellpadding="0" ></table>
  
    
  
    
  
        <table align="center">
        </br>
        
        
        <td  bgcolor="sky blue" >
            <a href="add.php"><font color="black">Click Here To See Fundamentals</font></a></td>
        </table>
  
  
  
  
  <?php
  ?>
        
     
   
</body>
</html>