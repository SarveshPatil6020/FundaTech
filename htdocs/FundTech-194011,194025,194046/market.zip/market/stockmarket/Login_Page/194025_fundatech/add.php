<!DOCTYPE HTML>
<html>
<title></title>
<head>
   
    <style> table, th, td {border : 3px solid rgba(5, 240, 36, 0.349);}</style>
</head> 
<body>

<form action="#" method="POST">

   













<h9 >
    <font face="Arial black"  size="20" color="black"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;VodafoneIdea Fundamentals</font>
</br></br></br></br> 
</h9>

<table align="center">
  <tr>
  <th bgcolor="yellow"><font face="Arial black" size="5"
    color="black">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;
   VodafoneIdea
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;</br>.</font></th>
  
  
  <th bgcolor="yellow">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2017-03&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
  <th bgcolor="yellow">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2018-03&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
  <th bgcolor="yellow">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2019-03&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
  <th bgcolor="yellow">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2020-03&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
  <th bgcolor="yellow">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2021-03&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
    </tr>

  <tr>
   <td  bgcolor="sky blue"><font face="Arial black" size="3"
     color="black">Revenue&nbsp;&nbsp;</font><font face="Arial black" 
     size="1" color="black">INR Mil</font>
     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
     &nbsp;&nbsp;&nbsp;&nbsp;

    </td>

    <td>355,527</td>
    <td>282,471</td>
    <td>370,056</td>
    <td>449,167</td>
    <td>419,382</td>

    
   </tr>

   <tr>
    <td  bgcolor="sky blue"><font face="Arial black" size="3"
        color="black">Operating Income&nbsp;&nbsp;</font><font face="Arial black" 
        size="1" color="black">INR Mil</font>
     </td>
     <td>24,093</td>
    <td>-23,487</td>
    <td>-109,676</td>
    <td>-148,817</td>
    <td>-68,794</td>
 
    </tr>
   
   <tr>
    <td  bgcolor="sky blue"><font face="Arial black" size="3"
        color="black">Net Income&nbsp;&nbsp;</font><font face="Arial black" 
        size="1" color="black">INR Mil</font>
     </td>
     <td>-3,997</td>
    <td>-41,681</td>
    <td>-146,039</td>
    <td>-738,781</td>
    <td>-442,331</td>
   
    </tr>

<tr>
    <td  bgcolor="sky blue"><font face="Arial black" size="3"
        color="black">EPS&nbsp;&nbsp;</font><font face="Arial black" 
        size="1" color="black">INR </font>
     </td>
     <td>0.67</td>
    <td>-6.68</td>
    <td>-17.17</td>
    <td>-27.26</td>
    <td>-15.40</td>
   

<tr>
    <td  bgcolor="sky blue"><font face="Arial black" size="3"
        color="black">Dividends&nbsp;&nbsp;</font><font face="Arial black" 
        size="1" color="black">INR</font>
     </td>
     <td>0.36</td>
    <td>_</td>
    <td>_</td>
    <td>_</td>
    <td>_</td>  
         
<tr>
    <td  bgcolor="sky blue"><font face="Arial black" size="3"
        color="black">Operating Cash flow per share&nbsp;&nbsp;</font><font face="Arial black" 
        size="1" color="black">INR Mil</font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
     </td>
     <td>1</td>
    <td>1</td>
    <td>1</td>
    <td>1</td>
    <td>1</td>
   
                 
</tr>

<tr>
    <td  bgcolor="sky blue"><font face="Arial black" size="3"
        color="black">Free Cash Flow&nbsp;&nbsp;</font><font face="Arial black" 
        size="1" color="black">INR Mil</font>
     </td>
     <td>1</td>
    <td>1</td>
    <td>1</td>
    <td>1</td>
    <td>1</td>
    
                     
</tr>
                 

</tr>
<tr>
    <td  bgcolor="sky blue"><font face="Arial black" size="3"
        color="black">Free Cash Flow Per Share&nbsp;&nbsp;</font><font face="Arial black" 
        size="1" color="black">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;INR Mil</font>
     </td>
     <td>1</td>
    <td>1</td>
    <td>1</td>
    <td>1</td>
    <td>1</td>
    

</tr>
</tr>
<tr>
    <td  bgcolor="sky blue"><font face="Arial black" size="3"
        color="black">Working Capital&nbsp;&nbsp;</font><font face="Arial black" 
        size="1" color="black">INR Mil</font>
     </td>
     <td>1</td>
    <td>1</td>
    <td>1</td>
    <td>1</td>
    <td>1</td>
</tr>

<tr>
    <td  bgcolor="sky blue"><font face="Arial black" size="3"
        color="black">Return on Assets&nbsp;&nbsp;</font><font face="Arial black" 
        size="1" color="black">INR %</font>
     </td>
     <td>1</td>
    <td>1</td>
    <td>1</td>
    <td>1</td>
    <td>1</td>

</tr>


<tr>
    <td  bgcolor="sky blue"><font face="Arial black" size="3"
        color="black">Return On Equity&nbsp;&nbsp;</font><font face="Arial black" 
        size="1" color="black">INR  %</font>
     </td>
     <td>1</td>
    <td>1</td>
    <td>1</td>
    <td>1</td>
    <td>1</td>
  
</tr>



<tr>
    <td  bgcolor="sky blue"><font face="Arial black" size="3"
        color="black">Return On Invested Capital &nbsp;&nbsp;</font><font face="Arial black" 
        size="1" color="black">INR  %</font>
     </td>
     <td>1</td>
    <td>1</td>
    <td>1</td>
    <td>1</td>
    <td>1</td>
  
</tr>

</table>




<table align="center">
    </br>
    
    
    <td  bgcolor="sky blue" >
    <input type="submit" bgcolor="black" value="Submit" name="submit" style="width: 500px;"  ></td>
    </table>


   
 
    
    

   
      
</form>
</body>
</html>

