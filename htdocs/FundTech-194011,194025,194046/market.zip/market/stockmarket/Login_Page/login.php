<?php

/// Database connectivity

$host="localhost";
$user="root";
$password="";
$db="fundatech";

$conn = mysqli_connect("localhost", "root" ,"", "fundatech" );



// Script alert Functions 

 function function_alert($message)
 {
   echo"<script> alert('$message')</script>";
 }


 function function_else($message)
 {
   echo"<script> alert('$message')</script>";
 }



$name = $_POST['name'];
$password = $_POST['password'];

if(isset($_POST['sent']))
{
  $result=mysqli_query($sql,$conn);


    $name=$_POST['name'];
    $password=$_POST['password'];
    
    $sql="SELECT * from signin where name='$name' AND password= '$password ' limit 1;"
    
    
    if($result)
       {
           function_alert("Login Successfully !!!!");
           
       }
       else{
           function_else("oops!!! incorrect password or Username");
       }
    
    
    }
  
  
    

?>

