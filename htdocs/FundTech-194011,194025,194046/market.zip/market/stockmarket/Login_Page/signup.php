
<?php
    $host="localhost";
    $user="root";
    $password="";
    $dbname="phpproject";
    $con = mysqli_connect($host,$user,$password,$dbname);
    $name = $_POST['name'];
    $tel =$_POST['tel'];
    $email = $_POST['email'];
    $password = $_POST['password'];
        if(!empty($email) && !empty($password) && !is_numeric($email))
        {
            //save to database
           
            $query = "INSERT INTO `signup` VALUES(00,'".$name."','".$password."','na','".$email."',91,'".$tel."','n')";
            mysqli_query($con, $query);
            header("Location: ../dist/index.html");
            die;
        }else{
                echo "Please enter some valid information";
            }    
?>