<?php
$host="localhost";
$user="root";
$password="";
$db="fundatech";

$conn = mysql_connect("localhost", "root" ,"", "fundatech" );

if($conn)
{
    echo"";
}else
{
    echo"SQL database Connection Failed";
}

?>