<?php 
$host="localhost";
$user="root";
$password="";
$dbname="phpproject";
$con = mysqli_connect($host,$user,$password,$dbname);
session_start();


if(isset($_POST['name'])){
    
    $name=$_POST['name'];
    $password=$_POST['password'];
    
    $sql="SELECT * from signup where email='$name'AND password='$password' limit 1";
    $result=mysqli_query($con,$sql);
    echo $name;
    if($name=="sp5196988@gmail.com" and $password=="S@rvesh"){
	 header("Location: 194025_fundatech/sidebar/dashboard.php");
    }else{
    if(mysqli_fetch_array($result)>0){
	$_SESSION["email"] = $name;
	$_SESSION["password"] = $password;
        header("Location: ../dist/index2.html");
    }
    else{
        echo $name;
        echo " You Have Entered Incorrect Password";
        die();
    } 
    }	
        
}
?>

